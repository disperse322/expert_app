package com.example.expert

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import android.widget.Button

data class Course(val title: String, val price: String, val duration: String)

class MainActivity : AppCompatActivity() {

    private val courses = listOf(
        Course("Повар", "22000₽", "460 часов"),
        Course("Парикмахер", "26000₽", "400 часов"),
        Course("Крановщик", "20000₽", "320 часов"),
        Course("Стропальщик", "10000₽", "180 часов"),
        Course("Слесарь", "20000₽", "320 часов"),
        Course("Оператор ЭВМ", "12000₽", "320 часов")
    )
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        sharedPreferences = getSharedPreferences("expert_prefs", MODE_PRIVATE)

        findViewById<CardView>(R.id.card1).setOnClickListener {
            saveCourseToProfile(courses[0])
            openDetail(courses[0])
        }
        findViewById<CardView>(R.id.card2).setOnClickListener {
            saveCourseToProfile(courses[1])
            openDetail(courses[1])
        }
        findViewById<CardView>(R.id.card3).setOnClickListener {
            saveCourseToProfile(courses[2])
            openDetail(courses[2])
        }
        findViewById<CardView>(R.id.card4).setOnClickListener {
            saveCourseToProfile(courses[3])
            openDetail(courses[3])
        }
        findViewById<CardView>(R.id.card5).setOnClickListener {
            saveCourseToProfile(courses[4])
            openDetail(courses[4])
        }
        findViewById<CardView>(R.id.card6).setOnClickListener {
            saveCourseToProfile(courses[5])
            openDetail(courses[5])
        }

        findViewById<Button>(R.id.profileButton).setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
        }
    }

    private fun saveCourseToProfile(course: Course) {
        sharedPreferences.edit().apply {
            putString("course_title", course.title)
            putString("course_price", course.price)
            putString("course_duration", course.duration)
            apply()
        }
    }

    private fun openDetail(course: Course) {
        val intent = Intent(this, DetailActivity::class.java).apply {
            putExtra("title", course.title)
            putExtra("price", course.price)
            putExtra("duration", course.duration)
        }
        startActivity(intent)
    }
}
