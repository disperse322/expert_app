package com.example.expert

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ProfileActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        findViewById<Button>(R.id.backButton).setOnClickListener { finish() }

        val sharedPreferences = getSharedPreferences("expert_prefs", MODE_PRIVATE)

        val title = sharedPreferences.getString("course_title", null)
        val price = sharedPreferences.getString("course_price", "")
        val duration = sharedPreferences.getString("course_duration", "")

        val profileTextView = findViewById<TextView>(R.id.profileTextView)
        if (title.isNullOrEmpty()) {
            profileTextView.text = "Курсы не выбраны"
        } else {
            profileTextView.text = "Вы записались на курс \"$title\"\nЦена: $price\nДлительность: $duration"
        }
    }
}
