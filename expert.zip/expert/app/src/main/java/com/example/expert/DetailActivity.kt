package com.example.expert

import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class DetailActivity : AppCompatActivity() {
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        sharedPreferences = getSharedPreferences("expert_prefs", MODE_PRIVATE)

        findViewById<Button>(R.id.backButton).setOnClickListener { finish() }

        val title = intent.getStringExtra("title")
        val price = intent.getStringExtra("price")
        val duration = intent.getStringExtra("duration")

        findViewById<TextView>(R.id.courseTitle).text = "Курс: $title"
        findViewById<TextView>(R.id.coursePrice).text = "Цена: $price"
        findViewById<TextView>(R.id.courseDuration).text = "Длительность обучения: $duration"

        findViewById<Button>(R.id.enrollButton).setOnClickListener {
            sharedPreferences.edit().apply {
                putString("course_title", title)
                putString("course_price", price)
                putString("course_duration", duration)
                apply()
            }
            Toast.makeText(this, "Вы записались на курс $title", Toast.LENGTH_SHORT).show()
        }
    }
}
